﻿namespace IfDemo {
    let x = 10;

    if (x === 10) {
        console.log(`x는 ${x}입니다.`);
    }

    if (x !== 20) {
        console.log(`x는 20이 아닙니다.`);
    }
}
