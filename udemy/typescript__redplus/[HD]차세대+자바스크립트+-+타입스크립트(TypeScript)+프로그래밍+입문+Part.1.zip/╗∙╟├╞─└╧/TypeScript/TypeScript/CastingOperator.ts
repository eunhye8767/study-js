﻿namespace CastingOperator {
    let number1 = parseInt("3.14"); // 3.14를 정수로 변환
    console.log(number1); // 3

    let number2 = parseFloat("3.14"); // 3.14를 실수로 변환
    console.log(number2); // 3.14
}
