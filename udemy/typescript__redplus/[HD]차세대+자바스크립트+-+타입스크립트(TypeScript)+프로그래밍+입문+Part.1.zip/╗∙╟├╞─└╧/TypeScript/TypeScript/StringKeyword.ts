﻿namespace StringKeyword {
    const name: string = "박용준";
    let age: number = 21;

    console.log("안녕하세요. " + name + "(" + age + ")입니다.");
}
