﻿namespace ArrayString {
    // 문자열 == 문자의 배열
    let arr = "TSC";
    console.log(arr[0]); // T
    console.log(arr[1]); // S
    console.log(arr[2]); // C
}
