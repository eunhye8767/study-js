﻿namespace StringCompare {
    let s1: string = "Hello.";
    let s2: string = "Hello.";

    // s1과 s2가 같으면 true
    if (s1 === s2) {
        console.log("Same");
    }
}
