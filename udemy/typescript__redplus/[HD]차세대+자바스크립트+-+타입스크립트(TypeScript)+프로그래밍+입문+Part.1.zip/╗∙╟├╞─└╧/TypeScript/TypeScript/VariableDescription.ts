﻿// 변수(Variable): 프로그램에서 사용할 데이터를 임시로 저장해 놓는 그릇
namespace VariableDescription {

    //[1] num 이름의 변수 만들고 1234로 초기화하기
    var num = 1234; 

    //[2] 변수 사용(참조)
    console.log(num);
    console.log(num + num);

}
