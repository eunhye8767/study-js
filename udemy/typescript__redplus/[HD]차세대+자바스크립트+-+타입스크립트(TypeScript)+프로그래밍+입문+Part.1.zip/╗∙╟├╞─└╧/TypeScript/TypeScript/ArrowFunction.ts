﻿module ArrowFunction {
    let f1 = function (message) {
        console.log(message);
    }

    let f2 = (message) => {
        console.log(message);
    }

    let f3 = (message) => console.log(message);

    f1("Arrow Function");
    f2("Lambda Expression");
    f3("람다 식");
}
