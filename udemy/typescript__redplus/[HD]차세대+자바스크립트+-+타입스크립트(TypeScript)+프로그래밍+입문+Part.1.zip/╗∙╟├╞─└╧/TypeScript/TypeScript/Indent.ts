﻿// Indent
{
    console.log("들여쓰기는 공백 4칸을 사용");
}
