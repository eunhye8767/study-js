﻿// ConsoleLogDemo.ts
console.log("명령 프롬프트에 출력할 내용");
