﻿//[?] 문자열 연결: 더하기 연산자, String.concat() 메서드
namespace StringConcat {
    let s1 = "안녕" + "하세요.";
    let s2 = "반갑".concat("습니다.");
    console.log(`${s1} ${s2}`);
}
