﻿const person: { name: string, age: number } = { name: "타이비", age: 10 };

console.log(`${person.name} -> ${person.age}`);

let my = {
    name: '박용준',
    age: 21,
}

my.age = 22;

