﻿console.log("Hello TypeScript 2018.02");
