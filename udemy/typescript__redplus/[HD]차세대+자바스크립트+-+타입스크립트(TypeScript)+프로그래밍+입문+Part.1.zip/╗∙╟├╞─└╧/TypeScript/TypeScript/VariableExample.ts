﻿module VariableExample {
    // 데이터 형식을 갖는 변수
    let n: number = 1234;
    let b: boolean = true;
    let s: string = '안녕하세요.';
    let a: any;
    a = 1234;
    a = true;
    a = '반갑습니다.';

    // 데이터 형식을 갖는 상수
    const PI: number = 3.14;

    // 데이터 형식을 갖는 배열
    let arr: number[] = [1, 2, 3];
    let all: any[] = [1234, true, '또 만나요.'];
}
