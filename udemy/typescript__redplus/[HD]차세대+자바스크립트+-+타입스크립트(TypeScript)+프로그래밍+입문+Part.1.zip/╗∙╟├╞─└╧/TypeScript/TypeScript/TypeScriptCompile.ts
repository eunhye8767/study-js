﻿function say(message) {
    console.log(message);
}

var msg = "안녕하세요.";

say(msg);
say('반갑습니다.');
