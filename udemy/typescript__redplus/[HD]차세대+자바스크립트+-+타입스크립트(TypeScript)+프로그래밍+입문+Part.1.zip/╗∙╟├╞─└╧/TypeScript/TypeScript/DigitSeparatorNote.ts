﻿// 세자라마다 콤마로 구분되는 숫자를 표현할 때 언더스코어(_) 문자로 구분 가능
namespace DigitSeparatorNote {
    const num = 1_000_000;
    console.log(num); // 1000000
}
