console.log("타입스크립트 개발 환경 구축");
