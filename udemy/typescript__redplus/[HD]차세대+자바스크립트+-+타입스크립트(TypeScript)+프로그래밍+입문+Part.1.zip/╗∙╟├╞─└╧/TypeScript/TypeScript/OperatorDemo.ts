﻿namespace OperatorDemo {
    var num = 1000;
    var number = num + 1234;
    console.log(number); 
}