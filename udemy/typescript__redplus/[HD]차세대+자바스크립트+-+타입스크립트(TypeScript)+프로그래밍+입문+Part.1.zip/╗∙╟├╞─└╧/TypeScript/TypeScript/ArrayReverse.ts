﻿//[?] Array 클래스의 reverse 메서드로 배열을 거꾸로 변환하기 
namespace ArrayReverse {
    let numbers = [1, 2, 3];

    numbers.reverse(); // 배열을 역순으로 변환

    for (let item of numbers) {
        console.log(item);
    }
}
