﻿{
    var hi = "안녕하세요."; 
}

console.log(hi); // "안녕하세요."