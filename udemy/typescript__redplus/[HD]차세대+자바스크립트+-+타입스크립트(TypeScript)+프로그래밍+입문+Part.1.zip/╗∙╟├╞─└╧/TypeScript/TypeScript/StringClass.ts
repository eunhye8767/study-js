﻿//[?] String 클래스 == string 키워드
namespace StringClass {
    let s1 = new String("안녕하세요."); // String 클래스
    let s2: string = "반갑습니다."; // string 키워드

    console.log(`${s1} ${s2}`);
}
