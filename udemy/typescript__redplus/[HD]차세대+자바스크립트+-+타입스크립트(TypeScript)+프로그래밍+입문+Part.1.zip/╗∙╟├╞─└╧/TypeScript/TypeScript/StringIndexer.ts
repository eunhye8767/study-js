﻿//[?] 문자열 인덱서: 문자열에 직접 인덱서([]) 사용하기 
namespace StringIndexer {
    console.log("ABC"[0]); // 'A'
    console.log("ABC"[1]); // 'B'
    console.log("ABC"[2]); // 'C'

    console.log(typeof "ABC"); // string
    console.log(typeof "ABC"[0]); // string
}
