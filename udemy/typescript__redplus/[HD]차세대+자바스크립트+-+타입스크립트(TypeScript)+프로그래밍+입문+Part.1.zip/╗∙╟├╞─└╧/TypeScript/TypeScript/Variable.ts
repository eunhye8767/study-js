﻿// 기존 JavaScript의 변수 선언
var i = 10;

// any 타입: 모든 값
var j: any;
j = "안녕";

// number: 숫자
var k: number;
//k = "안녕"; // 에러
k = 1234;

// 선언과 동시에 초기화
var bln: boolean = true;
bln = false;

// 문자열
var strHello: string = "안녕하세요.";

// 배열형
var arrHi: string[] = ["안녕", "잘가"];
