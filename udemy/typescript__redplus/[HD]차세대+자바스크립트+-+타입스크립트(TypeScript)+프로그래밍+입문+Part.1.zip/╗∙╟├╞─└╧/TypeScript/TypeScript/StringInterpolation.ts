﻿// TypeScript의 문자열 보간

// 문자열 보간(String Interpolation)
const message = "String Interpolation";

console.log("Message: " + message); 
console.log(`Message: ${message}`); // 백틱 기호(`)
console.log(`3 > 5: ${3 > 5}`); // 간단한 연산 수행
