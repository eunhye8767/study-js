﻿namespace Terms {
    //[?] 객체(Object), 개체(Object), 오브젝트, 클래스(Class), 인스턴스
    //[!] Date 객체/클래스의 인스턴스 생성
    const dateNow = new Date(); // Date 클래스의 생성자를 사용하여 dateNow 개체 생성
    console.log(dateNow);
    //[*] Date 객체, Date 개체, Date 오브젝트, Date 클래스, Date 인스턴스, Date 생성자
}
