﻿// CaseSensitive.ts
//Console.Log("타입스크립트는 대소문자 구분 언어"); //[1] Console is not defined 
//console.Log("타입스크립트는 대소문자 구분 언어"); //[2] console.Log is not a function 
console.log("타입스크립트는 대소문자 구분 언어!!!"); //[3] OK
