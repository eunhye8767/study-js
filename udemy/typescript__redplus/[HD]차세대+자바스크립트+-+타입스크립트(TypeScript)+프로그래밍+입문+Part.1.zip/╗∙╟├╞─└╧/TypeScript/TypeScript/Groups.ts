﻿enum Groups {
    Administrators,
    Users,
    Guests
}

console.log(Groups.Administrators);
console.log(Groups.Users);
console.log(Groups.Guests);
