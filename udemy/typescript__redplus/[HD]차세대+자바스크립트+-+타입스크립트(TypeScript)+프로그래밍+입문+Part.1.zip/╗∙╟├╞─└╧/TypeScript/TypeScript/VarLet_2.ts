﻿{
    let hi = "안녕하세요."; 
}

console.log(hi); // 에러 발생 => VarLet_2.ts(5,13): error TS2304: Cannot find name 'hi'.