﻿// 템플릿 문자열(문자열 보간법, 보간된 문자열)
let num = 3;
let result = "홀수";
console.log(`${num}은(는) ${result}입니다.`);
