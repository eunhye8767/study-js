﻿// 자바스크립트 방식
var num1 = 1234; // num1 변수는 number 형식으로 추론

// 타입스크립트 방식
var num2: number = 1234; 

console.log(typeof num1);
console.log(typeof num2);
