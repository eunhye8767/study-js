﻿
class Notation {
    static Store: any; 
}

