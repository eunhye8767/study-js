﻿// 자바스크립트 배열(Array)은 동적으로 push() 메서드로 요소 추가 가능
var cart = [];

cart.push("책");
cart.push("강의");
cart.push("컴퓨터");

console.log(cart); // ["책", "강의", "컴퓨터"]
