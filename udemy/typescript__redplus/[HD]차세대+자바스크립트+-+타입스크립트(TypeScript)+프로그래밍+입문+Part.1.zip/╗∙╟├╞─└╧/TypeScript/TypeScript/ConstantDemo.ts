﻿//[?] 상수(Constant): 변하지 않는 변수, 읽기 전용 변수
const MAX = 100; // 숫자 형식의 상수 선언과 동시에 초기화 
console.log(`최댓값: {MAX}`);
