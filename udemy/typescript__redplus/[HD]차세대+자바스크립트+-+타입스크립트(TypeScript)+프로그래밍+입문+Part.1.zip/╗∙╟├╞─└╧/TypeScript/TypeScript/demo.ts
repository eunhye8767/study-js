class Car {
	
}

var car = new Car();

var car3 = new Car();
