﻿//[?] 논리 자료형: 참(True) 또는 거짓(False) 값 저장
module BooleanDemo {
    let bln: boolean = true; // 참
    console.log(bln); // true

    let isFalse: boolean = false; // 거짓
    console.log(isFalse); // false
}
