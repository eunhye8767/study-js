﻿// CharacterArray
var characters = ['a', 'b', 'c', 'd']; // 문자 배열
console.log(characters.length); // 4

for (var i = 0; i < characters.length; i++) { // 배열의 크기만큼 반복
    console.log(characters[i]);
}
