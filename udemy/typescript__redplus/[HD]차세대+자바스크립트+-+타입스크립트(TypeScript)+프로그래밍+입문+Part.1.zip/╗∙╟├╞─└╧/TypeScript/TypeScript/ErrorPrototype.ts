﻿let myError = new Error("My Error");

myError.name
//'Error'

myError.message
//'My Error'

myError.toString()
//'Error: My Error'
