﻿try {
    if (true) {
        throw new Error();
    }
}
catch (exception) {
    console.log("에러가 발생했습니다.");
    console.log("정상 종료...");
}
