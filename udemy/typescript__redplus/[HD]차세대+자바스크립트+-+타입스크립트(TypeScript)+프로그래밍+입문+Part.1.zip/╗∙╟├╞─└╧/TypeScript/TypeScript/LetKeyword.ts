// var number1 = 3;
// let number2 = 3;

function printNumber(num) {
    for (let i = 0; i < num; i++) {
        console.log(i);
    }
    //console.log('최종: ' + i);
}

printNumber(3);
