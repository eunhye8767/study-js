﻿//[?] 정수형 변수의 값을 1씩 증가
namespace IncrementNumber {
    let num = 10;
    num = num + 1; // 1 증가
    console.log(num); // 11
}
