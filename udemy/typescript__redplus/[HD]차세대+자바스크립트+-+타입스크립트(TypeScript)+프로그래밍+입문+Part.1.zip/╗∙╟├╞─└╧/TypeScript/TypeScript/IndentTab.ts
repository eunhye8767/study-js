﻿//class IndentTab
{
    {
        console.log("탭 키 대신에 공백 4칸 사용");
            console.log("들여쓰기로 코드의 시작과 끝을 명확히");
    }
}
