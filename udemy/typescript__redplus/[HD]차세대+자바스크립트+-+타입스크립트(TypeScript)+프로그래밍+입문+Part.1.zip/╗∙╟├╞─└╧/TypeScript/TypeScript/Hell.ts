class Hello
{
   name: string;
}
