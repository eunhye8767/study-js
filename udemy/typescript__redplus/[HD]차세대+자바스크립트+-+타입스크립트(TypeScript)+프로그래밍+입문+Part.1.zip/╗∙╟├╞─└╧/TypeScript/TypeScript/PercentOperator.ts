﻿namespace PercentOperator {
    let f = 10;
    let s = 5;
    let r = f % s; // r 변수에는 (f / s) 결과의 나머지 값이 저장
    console.log(`${f} % ${s} = ${r}`);
}
