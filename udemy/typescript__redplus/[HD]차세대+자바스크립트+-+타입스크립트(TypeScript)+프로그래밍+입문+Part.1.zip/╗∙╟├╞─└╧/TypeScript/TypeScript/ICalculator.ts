﻿interface ICalculator {
    Add(): void;
    Subtract(): void;
    Multiply(): void;
    Divide(): void;
}

class Calculator implements ICalculator {
    Add(): void {

    }
    Subtract(): void {

    }
    Multiply(): void {

    }
    Divide(): void {

    }
}
