﻿// MultiLineString.ts
// 백틱(`) 기호를 사용하여 여러 줄 문자열 저장하기
var multiLines = `
    안녕하세요.
    반갑습니다.
`;

console.log(multiLines);
