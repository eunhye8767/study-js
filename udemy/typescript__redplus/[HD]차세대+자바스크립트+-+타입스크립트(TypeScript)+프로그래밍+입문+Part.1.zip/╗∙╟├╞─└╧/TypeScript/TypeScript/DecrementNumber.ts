﻿//[?] 정수형 변수의 값을 1씩 감소
namespace DecrementNumber {
    let num = 10;
    num = num - 1; // 1 감소
    console.log(num); // 9
}
