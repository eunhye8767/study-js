﻿console.log("줄\n바꿈");
