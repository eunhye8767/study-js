﻿module GoesTo {
    // 매개변수가 있는 함수 생성
    var multi = (num: number) => num * num;

    // 함수 호출
    console.log(multi(3)); // 9
}
