﻿var anyType: any;

anyType = 1234;
console.log(anyType);

anyType = "안녕하세요.";
console.log(anyType);

anyType = true;
console.log(anyType);
