﻿console.log("공통: 웹과 노드");
window.alert("웹 전용 대화상자");
