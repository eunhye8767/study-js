//// import Util = require("util");
//// Util.add(1, 2);

//// import * as Util from "util";
//// Util.divide(1, 2);

//import {add, divide} from "util";

//add(1, 2);
//divide(2, 4);
