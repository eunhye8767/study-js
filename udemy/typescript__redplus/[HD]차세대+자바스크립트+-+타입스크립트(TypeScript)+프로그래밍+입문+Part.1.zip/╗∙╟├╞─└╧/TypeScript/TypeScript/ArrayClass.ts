﻿// 자바스크립트 내장 개체인 Array 클래스를 사용하여 배열 만들기
var array1 = new Array(); // []
var array2 = new Array(3); // array2.length === 3 
var array3 = new Array(1, 2, 3); // [ 1, 2, 3 ]

console.log(array1);
console.log(array2);
console.log(array3);
