﻿namespace PlusOperator {
    let i = 10;
    let j = 20;
    let k = i + j; // k = 10 + 20
    console.log(k); // 30
}
