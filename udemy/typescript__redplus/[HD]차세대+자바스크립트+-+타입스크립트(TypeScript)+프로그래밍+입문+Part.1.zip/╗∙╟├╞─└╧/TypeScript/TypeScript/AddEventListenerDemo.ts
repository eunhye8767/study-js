﻿var btn = document.getElementById("btn");

// 이벤트 이름과 무명 메서드를 매개 변수로 지정
btn.addEventListener("click", function () {
    console.log("Clicked!!!");
});
