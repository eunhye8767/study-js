﻿//[?] 연산자(Operator): 더하기, 빼기와 같은 연산을 진행하는 키워드
namespace OperatorDescription {
    //[?] 식(Expression)
    console.log(3 + 5); // 8
    console.log(3 - 5); // -2

    //[?] 문(Statement) 
    console.log(3 * 5); // 15
    console.log(3 / 5); // 0
}
