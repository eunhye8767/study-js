﻿//class IndentSpaceTab
{
  console.log("2칸");
    console.log("4칸");
		console.log("탭");
}
