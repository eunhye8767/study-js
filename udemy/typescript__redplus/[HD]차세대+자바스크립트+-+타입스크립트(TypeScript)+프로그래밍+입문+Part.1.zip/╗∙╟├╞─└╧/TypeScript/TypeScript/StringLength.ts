﻿//[?] 문자열의 길이: String.length 속성
namespace StringLength {
    let s1 = "Hello.";
    let s2 = "안녕하세요.";
    console.log(`${s1.length}, ${s2.length}`);
}
