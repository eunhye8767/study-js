﻿// Literal.ts
console.log(1234);    //[1] 1234: 정수 리터럴
console.log(3.14);    //[2] 3.14: 실수 리터럴
console.log('A');     //[3] A: 문자 리터럴
console.log("HELLO"); //[4] HELLO: 문자열 리터럴
