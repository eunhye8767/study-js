﻿namespace DuckTyping {
    let duck = { id: 1, name: "Duck 1" };
    console.log(`${duck.id} - ${duck.name}`);

    duck = { id: 2, name: "Duck 2" };
    console.log(`${duck.id} - ${duck.name}`);

    //duck = { id: 3 };
    //duck = { id: 3, name: "Duck 3", email: "Email 3" };

    duck = { id: 3, name: "Duck 3" };
    console.log(`${duck.id} - ${duck.name}`);
}
