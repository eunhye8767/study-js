﻿module Immutable {
    // 상수: 변하지 않는 값
    const name = "RedPlus";

    // 변수: 변하는 값
    var age = 21;

    console.log(`Name: ${name}, Age: ${age}`);
}
