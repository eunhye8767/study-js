﻿namespace ProjectTest {
    let message = "TSC 요청하면 현재 폴더의 TS 파일들은 모두 자동으로 컴파일됩니다.";
    console.log(message); 
}