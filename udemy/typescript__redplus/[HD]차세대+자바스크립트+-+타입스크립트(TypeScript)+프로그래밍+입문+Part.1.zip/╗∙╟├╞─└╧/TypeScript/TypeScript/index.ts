console.log("TypeScript");
