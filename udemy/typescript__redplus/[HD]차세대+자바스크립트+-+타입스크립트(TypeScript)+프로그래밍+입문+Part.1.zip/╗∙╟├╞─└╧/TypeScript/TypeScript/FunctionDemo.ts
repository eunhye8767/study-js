﻿namespace FunctionDemo {
    //[1] show 함수 선언
    function show() {
        console.log("Hello World");
    }

    //[2] 호출
    show();
}
