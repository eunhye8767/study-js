﻿namespace ArraySort {
    let arr = [3, 2, 1, 4, 5];
    let sortedArray = arr.sort(); // 오름차순 정렬: 1, 2, 3 순서
    console.log(sortedArray);
    for (let item of sortedArray) {
        console.log(item);
    }
}
