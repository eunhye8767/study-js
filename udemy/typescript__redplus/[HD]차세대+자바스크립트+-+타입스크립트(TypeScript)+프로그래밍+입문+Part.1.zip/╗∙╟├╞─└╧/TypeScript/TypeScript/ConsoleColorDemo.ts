﻿// ConsoleColor 열거형으로 콘솔의 전경색 및 배경색 표현하기
namespace ConsoleColorDemo {
    enum ConsoleColor {
        Red,
        Green,
        Blue
    }

    console.log(ConsoleColor.Red); // 0
    console.log(ConsoleColor.Green); // 1
    console.log(ConsoleColor.Blue); // 2
}
