﻿// Whitespace.ts
// 공백(Whitespace): 프로그래밍 언어에서 공백은 무시된다. 
console.log("타입스크립트");
console.    log( "TypeScript" ) ;
console
    .log(
        "타입스크립트")
;
