/**
 * 리터럴
 *
 * 데이터 값
 */

const obj = {
	name: 'jang',
};

123;

('jang'); // => new String('jang');

[1, 2, 3]; // => new Array(1, 2, 3);
