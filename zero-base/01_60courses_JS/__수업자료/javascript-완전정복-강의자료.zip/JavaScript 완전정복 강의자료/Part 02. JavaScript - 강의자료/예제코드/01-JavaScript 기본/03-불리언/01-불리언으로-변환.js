/**
 * Boolean
 *
 * ON: True
 * OFF: False
 */
console.log(Boolean('STRING'));
console.log(!!'STRING');
console.log(!!0);
console.log(!!1);

if ( ) {
  // some code
} else {
  // some code
}
