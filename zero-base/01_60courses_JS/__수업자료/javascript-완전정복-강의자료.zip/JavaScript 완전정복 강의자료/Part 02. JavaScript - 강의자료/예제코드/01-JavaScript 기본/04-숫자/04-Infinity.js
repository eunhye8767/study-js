/**
 * Infinity
 * - 너무 크거나 작다
 * - 지수 1023까지 허용
 */
isFinite(Math.pow(2, 1024));
7 / 0;
isFinite(Infinity);
isFinite(NaN);
isFinite(19);
