//  기본 한 줄 주석
/* 기본 한 줄 주석 */

/*
  여러 줄 주석
  입니다.
 */

console.log('Hello ' /* 끼워넣기 */ + 'World');

// JSDOC
/**
 * Represents a book
 * @constructor
 * @param {string} title
 * @param {string} author
 */
function Book(title, author) {}
