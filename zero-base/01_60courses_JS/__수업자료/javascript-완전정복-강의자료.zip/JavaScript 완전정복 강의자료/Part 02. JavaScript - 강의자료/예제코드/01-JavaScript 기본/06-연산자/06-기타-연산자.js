/**
 * 기타 연산자
 */

console.log(123, 'ABC', false);

// 표현식 결과를 버릴때
void 1;
void 0;
void (10 + 10);

const test: string = '문자열';
const test2: number = 123;

function voidFunction() {
	return undefined;
}

// onClick: URL void;
