/**
 * - 타입 변환
 * 암시적 & 명시적
 */

const result1 = String(1) + '입니다';
const result2 = Number('11') + 11;
const result3 = Number('5') * 3;
const result4 = Number(String(['111'])) + 111;
