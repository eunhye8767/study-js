/**
 * 값 (즉. 값 식)
 */
1;
('문자열 값');
true;
false;
null;
undefined;

// ...레퍼런스 타입 값

// 값은로 귀결된 식 or 연산식
1 + 1;
1 > 2;
'안' + '녕' + '하세요';

/**
 * 문
 */


// 인터프리터에게 명령한다. 그것을 지시문으로
let isFlag = false

if (1 + 1 > 0) {
  isFlag = true
}

if (isFlag) {
  return '성공'
}


if (식) {

}


for (식) {

}

while (식) {

}