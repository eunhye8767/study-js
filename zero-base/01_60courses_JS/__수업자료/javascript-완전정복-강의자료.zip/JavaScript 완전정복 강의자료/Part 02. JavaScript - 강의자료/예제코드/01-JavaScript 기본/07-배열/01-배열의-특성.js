/**
 * 배열
 *
 * 1. 객체
 * 2. index: value (딕셔너리)
 */
const arr = [1, 2, 3];
arr[0];
arr[1];
arr[2];
arr[3] = 4;
arr.push(5);

arr[6];
arr.prop = [6, 7];
arr[9] = 10;
arr['prop'];

const arr2 = new Array(1, 2, 3);
