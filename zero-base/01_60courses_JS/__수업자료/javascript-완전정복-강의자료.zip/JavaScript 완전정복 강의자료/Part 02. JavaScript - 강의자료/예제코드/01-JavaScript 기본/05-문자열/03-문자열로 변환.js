String(123);
String(undefined);
String(null);
String({});
String({ name: 'jang' });
String([1, 2, 3]);

JSON.stringify([1, 2, 3]);
JSON.stringify({ name: 'jang' });

['1', 123].toString();

String(true);
Boolean(false);
Boolean(String('false'));
