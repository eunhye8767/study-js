/**
 * 함수
 */

// 함수 선언문 (매개변수 X)
function func() {
	if (10 > 0) {
		return 'Hello';
	}

	return undefined;
}

// 함수 선언문 (매개변수 O)
function sum(num1, num2, num3, num4) {
	return num1 + num4;
}

// 함수 선언문 (매개변수 O)
function multiple(num1, num2) {
	return num1 * num2;
}

// 반환 없는 함수
function voidFunc() {
	console.log('void func');
}
