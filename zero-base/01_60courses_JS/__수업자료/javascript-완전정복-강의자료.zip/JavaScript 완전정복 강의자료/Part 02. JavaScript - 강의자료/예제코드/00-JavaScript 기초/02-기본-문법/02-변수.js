/**
 * - 추천
 * 선언과 동시에 할당
 */

const lang = 'JavaScript';

// 선언
let lang2;

// 할당
lang2 = 'JS';

// 재할당
lang2 = 'JS';

// 선언과 동시에 할당
let lang3 = 'JavaScript';

// 재할당
lang3 = 'JS';

let count = 0;

// 복합 할당 연산자 (예측하기 어려움)
count += 1;

// 잘 읽히고 예상하기 쉬움
count += 1;
