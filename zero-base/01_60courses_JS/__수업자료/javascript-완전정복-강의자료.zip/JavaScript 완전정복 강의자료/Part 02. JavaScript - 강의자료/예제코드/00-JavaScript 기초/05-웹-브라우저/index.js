console.log('in the js');
