/**
 * 숫자
 */

console.log(1 === 1.0);
console.log(Math.pow(2, 9999));
console.log(Number.MAX_SAFE_INTEGER);
